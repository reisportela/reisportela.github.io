# AGENTS.md

## AI-Assisted Preparation of the Keynote  
**“Augmenting Stata with Artificial Intelligence”**

This repository supports the preparation of the Beamer presentation  
**_Augmenting Stata with Artificial Intelligence_**, delivered at the **Stata Users Group Meeting – Portugal 2026**.

All presentation-related material is located in the `presentation/` folder.

The repository contains **presentation materials only** (slides, figures, illustrative snippets). It **does not host the full development history or source code** of the software discussed in the keynote.

**Speaker**: Miguel Portela  
**Affiliation**: Escola de Economia, Gestão e Ciência Política, Universidade do Minho  
**Event page**: https://stata-uk.com/stata-portugal-2026.html

---

## Purpose of This Repository

The objective of this repository is to:

- Develop and maintain the **Beamer slides** used in the keynote
- Organize **illustrative examples** used for exposition
- Support a clear narrative on **how artificial intelligence can augment Stata users’ capacity to program, extend, and improve Stata commands**
- Ensure consistency between the technical narrative and the material presented

This repository is **not** the development repository for `xhdfe` or any other Stata package.

---

## Guard Rails: Workspace and System Safety

When working in this project, AI agents may use any software available on this computer (including `stata-mp`, Python, and system tools).

Default boundaries:

- Keep repository file edits focused on this project folder unless the user explicitly asks otherwise.
- Installing Python or Stata packages is allowed when this does not alter OS-level configuration or core runtime versions.

Permission required first (explicit user approval):

- Any action that can affect the operating system or the functioning of other software.
- Installing, removing, or upgrading system-level software, services, or package manager components.
- Installing or switching Python versions, changing the default Python interpreter, or modifying global shell/profile `PATH` settings.
- Any global environment change that may interfere with existing tools, projects, or the current Python setup.

Python safety example:

- Allowed without extra approval: install Python packages in a project-scoped environment.
- Not allowed without approval: install another Python version or interfere with the current Python version/interpreter behavior.

---

## Focus of the Presentation

Although AI tools are used during the preparation of the slides, the **substantive focus of the presentation** is:

> How artificial intelligence can augment the ability of Stata users to  
> program more efficiently, modernize existing commands, and develop  
> high-performance extensions to Stata.

The talk is not about AI-assisted slide making, but about **AI-assisted Stata programming and command development**.

---

## AI Tools and Their Roles (Presentation Context)

### Codex (Primary, via VS Code)

Codex is the main AI tool discussed in the presentation and used in the underlying work to:

- Assist in coding **C++ backends**, **Stata plugins**, and **ADO files**
- Generate and refactor code structures
- Draft technical explanations, documentation, and help files

In this repository, Codex is used mainly as a **writing and editing assistant** for presentation materials.

---

### Claude (Conceptual Discussion and Feedback)

Claude is used to:

- Discuss conceptually possible solutions to computational or design bottlenecks
- Provide feedback on alternative implementation strategies
- Help refine the narrative and framing of technical ideas

Claude acts as a **conceptual reviewer**, not as the primary programmer.

---

### Gemini (Occasional Cross-Checks)

Gemini is used sparingly to:

- Double-check programming options or alternative approaches
- Provide secondary validation of implementation choices

---

## Relationship to the Underlying Software Work

The keynote draws on **separate, ongoing development work** (including the `xhdfe` project), which:

- Is developed in a **different repository**
- Has its own documentation, logs, benchmarks, and validation procedures
- Is not mirrored or versioned here

Any references to implementation details in the slides are:

- Selective
- Simplified for exposition
- Intended to illustrate *principles and workflows*, not full technical specifications

---

## What Is AI-Assisted Here (and What Is Not)

### AI-Assisted in This Repository

- Slide drafting and revision
- Textual explanations
- Structural organization of the presentation
- Pedagogical and illustrative examples

### Not AI-Delegated

- Econometric interpretation
- Performance claims
- Numerical results
- Validation of algorithms
- Software correctness

All substantive claims made in the presentation remain the responsibility of the speaker.

---

## Transparency Statement

This presentation is prepared using AI tools in a **supporting role**, consistent with the message of the keynote:

> AI augments productivity and lowers barriers, but does not replace  
> econometric reasoning, validation, or accountability.

This repository documents the **presentation process**, not the full software engineering process.

---

## Use of Online Information

Online resources and public discussions may be used as input for the preparation of this talk.  
Whenever relevant, **sources are explicitly referenced** in the presentation materials.

---

## Live Demo

You use my Stata by issuing stata-mp.

---

*This document itself was drafted with AI assistance and revised by the author, consistent with the workflow described above.*
