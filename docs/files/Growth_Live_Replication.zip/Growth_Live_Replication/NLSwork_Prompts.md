# NLSwork Prompts for Live Session

Use this sequence to build and discuss a classic human-capital wage example with `webuse nlswork`.

## Prompt 1: Build the nlswork analysis do-file

```text
Write a Stata do-file that: (1) loads the nlswork dataset; (2) produces basic descriptive statistics including histograms of wages and experience and a scatter plot; (3) estimates two human capital wage equations — one with OLS and one with individual fixed effects — including education, experience, experience squared, tenure, and union status; (4) exports the estimation results to a well-formatted LaTeX table using esttab.
```

## Prompt 2: Add interpretation comments after running

```text
Run the do-file. Read the estimation output. Write a concise discussion of the OLS and FE results as comments at the end of the do-file. Focus on the returns to education, the experience profile, the union premium, and the differences between OLS and FE estimates.
```

## Reference script and expected exports

- Script: `demo/scripts/04_nlswork_human_capital.do`
- Table: `paper/tables/nlswork_human_capital.tex`
- Figures:
  - `paper/figures/stata/nlswork_hist_wage.pdf`
  - `paper/figures/stata/nlswork_hist_experience.pdf`
  - `paper/figures/stata/nlswork_scatter_wage_experience.pdf`
