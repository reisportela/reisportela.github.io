# Growth Prompts for Live Session

This file contains a clean, sequential set of prompts to replay the full workflow live: from raw data + paper template to a reproducible Stata pipeline with processed data, tables, figures, and regressions.

Use prompts in order. Copy/paste each prompt exactly in the chat with Codex.

For the separate bank-level panel exercise, use `Bankscope_Prompts.md`.

## Prompt 1: Build the project pipeline from raw data

```text
DEMO: for this presentation, I want to run a live session showing how AI agents, specifically Codex, can be used to program and execute Stata code, the first exercise to be executed is: explore the data in the folder demo/data/growth, build a country-level panel dataset including gdp, education and capital, organize the project structure inside demo by creating folders for scripts and logs, construct a clean and well-structured panel dataset that will later be used to estimate a growth regression
```

## Prompt 2: Create and test growth regressions (OLS + FE)

```text
create a do file to estimate two growth models, using ols and fe, test the code, iterate until it works
```

## Prompt 3: Fix path robustness for live execution

```text
i get path errors when running from other folders. set a hard main folder in the do file 02 as /Users/miguelportela/Library/CloudStorage/Dropbox/1.miguel/AI/Confs/Stata_13FEV2026/demo and test it from outside the project
```

## Prompt 4: Apply hard main folder to all scripts

```text
do this for all do files in the scripts folder
```

## Prompt 5: Add descriptive stats, output tables, and figures for paper

```text
in 02 estimate growth models, insert a set of descriptive statistics and graphs, create a table with descriptive statistics and another with the regression output that feed the tex of the paper, run and iterate until everything works
```

## Prompt 6: Keep only main tables/figure in LaTeX

```text
remove the regressions plot and the robustness checks in the latex
```

## Prompt 7: Keep do-file clean and use esttab for LaTeX exports

```text
the do file should also not be producing the regressions plot, use esttab to export the results to the latex of the paper, keep the do file effective, but clean, the goal is that the audience can easily follow the code
```

## Prompt 8: Add inline discussion comments in do-file

```text
run the 02 do file and insert a discussion of descriptive statistics and regression results as comments to the do file
```

## Prompt 9: Revise econometric model to use lagged regressors

```text
revise the econometric model, the explanatory variables should be in lags
```

## Prompt 10: Final cleanup of obsolete lines

```text
clean from the do file 02 the lines that are no longer needed, from the lines delete graphs do not exist any longer
```

## Prompt 11: Final validation pass

```text
run demo/scripts/02_estimate_growth_models.do and compile paper/main.tex, then report the final generated files for tables and figures
```

## Expected final artifacts

After running the sequence, you should have:

- `demo/scripts/00_explore_growth_data.do`
- `demo/scripts/01_build_growth_panel.do`
- `demo/scripts/02_estimate_growth_models.do`
- `demo/scripts/run_growth_demo.do`
- `demo/data/processed/growth_panel_merged.dta`
- `demo/data/processed/growth_panel_clean.dta`
- `demo/data/processed/growth_regression_sample.dta`
- `paper/tables/summary_stats.tex`
- `paper/tables/regression_main.tex`
- `paper/figures/stata/descriptive_trends.pdf`
