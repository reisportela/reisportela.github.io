# Live Replication Kit: Augmenting Stata with AI

This package is designed for a live session where participants replicate an AI-assisted workflow from:
- raw data,
- a paper LaTeX file,
- prompt sequence,
- and project-level AI instructions.

## Included files

- `AGENTS.md`
- `Growth_Prompts.md`
- `Bankscope_Prompts.md`
- `NLSwork_Prompts.md`
- `demo/data/growth/pwt70.xls`
- `demo/data/growth/barro_lee_aeduc.xlsx`
- `demo/data/growth/cap_inv.xls`
- `demo/data/firms/Bankscope_example.xls`
- `demo/scripts/03_build_bankscope_panel.do` (reference solution)
- `demo/scripts/04_nlswork_human_capital.do` (reference solution)
- `paper/main.tex`
- `paper/README.md`
- `paper/Makefile`

## Goal of the live exercises

Use the prompts in `Growth_Prompts.md` sequentially with Codex to generate and iterate on Stata code that:
1. explores and assembles a panel dataset,
2. estimates growth regressions,
3. exports descriptive/regression tables to LaTeX,
4. exports a figure,
5. compiles the paper.

Use `Bankscope_Prompts.md` for the second exercise:
1. build a bank-year panel from a Bankscope export,
2. clean and standardize variables,
3. set panel structure (`xtset bank_id year`),
4. export a final panel dataset (`.dta` and `.csv`).

Use `NLSwork_Prompts.md` for an additional human-capital exercise:
1. load `nlswork` from `webuse`,
2. produce descriptives and plots,
3. estimate OLS and individual FE wage equations,
4. export a LaTeX regression table with `esttab`.

## Quick run (Bankscope reference script)

From this repository root:

```bash
stata-mp -b do share/Growth_Live_Replication/demo/scripts/03_build_bankscope_panel.do
```

From inside an extracted replication kit:

```bash
stata-mp -b do demo/scripts/03_build_bankscope_panel.do
```

## Quick run (NLSwork reference script)

From this repository root:

```bash
stata-mp -b do share/Growth_Live_Replication/demo/scripts/04_nlswork_human_capital.do
```

From inside an extracted replication kit:

```bash
stata-mp -b do demo/scripts/04_nlswork_human_capital.do
```

## Suggested live flow

1. Open this folder in your editor.
2. Start Codex and use prompts from `Growth_Prompts.md` one-by-one.
3. Run the Bankscope sequence from `Bankscope_Prompts.md`.
4. Run the nlswork sequence from `NLSwork_Prompts.md`.
5. Let Codex create folders/scripts and run Stata.
6. Compile the paper after the growth regression/export steps.

## Environment assumptions

- Stata is installed and callable from terminal (e.g. `stata-mp`).
- LaTeX is installed (`latexmk`, `pdflatex`) for paper compilation.
- Internet may be required once for `estout` installation (`esttab`).
