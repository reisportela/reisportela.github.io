# Paper Template (LaTeX + Stata Outputs)

This folder contains a paper-style LaTeX template that is ready to receive:

- summary statistics tables exported from Stata
- regression tables exported from Stata
- figures exported from Stata

## Structure

- `main.tex`: main paper source
- `tables/`: Stata-generated `.tex` table fragments
- `figures/stata/`: Stata-generated figures (e.g., `.pdf`, `.png`)
- `Makefile`: build helper

## Quick Start

1. Export outputs from Stata into this folder structure.
2. Compile with:

```bash
cd paper
make
```

## Stata Export Examples

Use `fragment` so Stata writes only the tabular body, which is what `main.tex` expects.

```stata
* Summary statistics
estpost summarize y x1 x2
esttab using "paper/tables/summary_stats.tex", replace ///
    cells("mean(fmt(3)) sd(fmt(3)) min(fmt(3)) max(fmt(3)) count(fmt(0))") ///
    label nonumber nomtitle noobs booktabs fragment

* Main regression table
reg y x1 x2 i.year, vce(robust)
eststo m1
xtreg y x1 x2 i.year, fe vce(cluster id)
eststo m2
esttab m1 m2 using "paper/tables/regression_main.tex", replace ///
    se star(* 0.10 ** 0.05 *** 0.01) label booktabs fragment

* Robustness table
reg y x1 x2 x3 i.year, vce(robust)
eststo r1
esttab r1 using "paper/tables/regression_robustness.tex", replace ///
    se star(* 0.10 ** 0.05 *** 0.01) label booktabs fragment

* Figure export
twoway (line y year), title("Descriptive Trends")
graph export "paper/figures/stata/descriptive_trends.pdf", replace
```

## Notes

- If a file is missing, `main.tex` shows a visible placeholder instead of failing.
- You can rename files, but then update the corresponding paths in `main.tex`.
