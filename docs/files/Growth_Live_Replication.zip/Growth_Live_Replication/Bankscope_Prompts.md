# Bankscope Prompts for Live Session

This file adds a second live exercise focused on bank-level panel construction from a Bankscope export.

Use prompts in order. Copy/paste each prompt exactly in the chat with Codex.

## Prompt 1: Build and run the Bankscope panel do-file

```text
create and execute a do file that builds a panel from Bankscope_example.xls
```

## Prompt 2: Harden the script for replication sharing

```text
refine the bankscope do file so it is reproducible in this replication kit, with clear variable names, xtset bank_id year, and exports to demo/data/processed in both dta and csv
```

## Prompt 3: Validate final output and report summary

```text
run the bankscope do file and report banks, years, and total observations in the final panel dataset
```

## Expected final artifacts

After running the sequence, you should have:

- `demo/scripts/03_build_bankscope_panel.do`
- `demo/data/processed/bankscope_panel.dta`
- `demo/data/processed/bankscope_panel.csv`

